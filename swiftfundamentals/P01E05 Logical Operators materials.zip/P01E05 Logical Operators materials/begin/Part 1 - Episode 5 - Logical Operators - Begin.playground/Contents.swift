//: ## Episode 05: Logical Operators

let passingGrade = 50
let studentGrade = 50
let chrisGrade = 49
let samGrade = 99

